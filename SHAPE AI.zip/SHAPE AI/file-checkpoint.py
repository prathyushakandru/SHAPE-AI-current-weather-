{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 35,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "Enter city name : guntur\n",
      "Weather Information for City: guntur\n",
      "Temperature (Celsius): 29\n",
      "Feels like in (Celsius): 33\n",
      "Pressure: 1006 hPa\n",
      "Humidity: 66%\n",
      "Wind speed: 20.52 km/hr\n",
      "Sunrise at 05:37:24 and Sunset at 18:43:15\n",
      "Cloud: 89%\n",
      "Info: moderate rain\n"
     ]
    }
   ],
   "source": [
    "import requests\n",
    "import json\n",
    "from datetime import datetime\n",
    "def time_from_utc_with_timezone(utc_with_tz):\n",
    "    local_time = datetime.utcfromtimestamp(utc_with_tz)\n",
    "    return local_time.time()\n",
    "api_key = \"ae7b634673d4ee94a61e157ca9984def\"\n",
    "city_name = input(\"Enter city name : \")\n",
    "weather_url = 'http://api.openweathermap.org/data/2.5/weather?q=' + city_name + '&appid='+api_key\n",
    "response = requests.get(weather_url)\n",
    "weather_data = response.json()\n",
    "if weather_data['cod'] == 200:\n",
    "    kelvin = 273.15 # Temperature shown here is in Kelvin and I will show in Celsius\n",
    "    temp = int(weather_data['main']['temp'] - kelvin)\n",
    "    feels_like_temp = int(weather_data['main']['feels_like'] - kelvin)\n",
    "    pressure = weather_data['main']['pressure']\n",
    "    humidity = weather_data['main']['humidity']\n",
    "    wind_speed = weather_data['wind']['speed'] * 3.6\n",
    "    sunrise = weather_data['sys']['sunrise']\n",
    "    sunset = weather_data['sys']['sunset']\n",
    "    timezone = weather_data['timezone']\n",
    "    cloudy = weather_data['clouds']['all']\n",
    "    description = weather_data['weather'][0]['description']\n",
    "    sunrise_time = time_from_utc_with_timezone(sunrise + timezone)\n",
    "    sunset_time = time_from_utc_with_timezone(sunset + timezone)\n",
    "    print(f\"Weather Information for City: {city_name}\")\n",
    "    print(f\"Temperature (Celsius): {temp}\")\n",
    "    print(f\"Feels like in (Celsius): {feels_like_temp}\")\n",
    "    print(f\"Pressure: {pressure} hPa\")\n",
    "    print(f\"Humidity: {humidity}%\")\n",
    "    print(\"Wind speed: {0:.2f} km/hr\".format(wind_speed))\n",
    "    print(f\"Sunrise at {sunrise_time} and Sunset at {sunset_time}\")\n",
    "    print(f\"Cloud: {cloudy}%\")\n",
    "    print(f\"Info: {description}\")\n",
    "else:\n",
    "    print(f\"City Name: {city_name} was not found!\")\n",
    "f=open(\"project.txt\",\"w\")\n",
    "f.write(f\"Weather Information for City:{city_name}\" )\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Temperature (Celsius): {temp}\")\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Feels like in (Celsius): {feels_like_temp}\")\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Pressure: {pressure} hPa\")\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Humidity: {humidity}%\")\n",
    "f.write(\"\\n\")\n",
    "f.write(\"Wind speed: {0:.2f} km/hr\".format(wind_speed))\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Sunrise at {sunrise_time} and Sunset at {sunset_time}\")\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Cloud: {cloudy}%\")\n",
    "f.write(\"\\n\")\n",
    "f.write(f\"Info: {description}\")\n",
    "f.close()\n",
    "\n",
    "\n"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.4"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 2
}
